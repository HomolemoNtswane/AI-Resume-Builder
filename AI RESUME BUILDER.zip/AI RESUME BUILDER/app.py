from flask import Flask, render_template, request, make_response, send_file, session
import cohere
from xhtml2pdf import pisa
from io import BytesIO

app = Flask(__name__)
app.secret_key = 'V12345'

# Initialize Cohere client
co = cohere.Client('i5CF3sStWeTPbBnaBm15r3d7XgSI5VzIhk7ZOjTF')

@app.route('/', methods=['GET', 'POST'])
def resume_form():
    if request.method == 'POST':
        name = request.form.get('name')
        job_title = request.form.get('job_title')
        experience = request.form.get('experience')
        education = request.form.get('education')
        skills = request.form.get('skills')
        projects = request.form.get('projects')

        prompt = f"""
Write a complete professional resume for the following candidate.

Name: {name}
Target Job Title: {job_title}
Experience: {experience}
Education: {education}
Skills: {skills}
Projects: {projects}

Format the output with the following sections:
1. Professional Summary
2. Work Experience
3. Education
4. Skills
5. Projects

Use a formal and confident tone. Keep it ATS-friendly.
"""

        response = co.generate(
            model='command',
            prompt=prompt,
            max_tokens=800,
            temperature=0.6
        )

        resume_text = response.generations[0].text.strip()

        session['resume'] = resume_text
        session['name'] = name

        return render_template('result.html', resume=resume_text, name=name)

    # This part runs only if it's a GET request
    return render_template('form.html')

@app.route('/download', methods=['POST'])
def download_pdf():
    resume = request.form.get('resume')
    name = request.form.get('name')
    template_choice = request.form.get('template')  
    
    resume = session.get('resume')
    name = session.get('name')

    if not resume or not name:
        return "No resume data found. Please generate the resume first."

    html = render_template(template_choice, resume=resume, name=name)

    # Generate PDF
    pdf_file = BytesIO()
    pisa.CreatePDF(BytesIO(html.encode('utf-8')), dest=pdf_file)
    pdf_file.seek(0)

    return send_file(pdf_file, download_name="resume.pdf", as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
























    





